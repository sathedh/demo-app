// import React from "react";
// import DataTable from "react-data-table-component";


// const ReactDataTable = () => {
//     const columns = [
//         {
//             name: "name",
//             //selector: row => row.name,
//             sortable: true
//         },
//         {
//             mrn: "MRN",
//             //selector: row => row.mrn,
//             sortable: true
//         },
//         {
//             treatmentPlan: "Treatment Plan",
//             //selector: row => row.treatmentPlan,
//             sortable: true
//         },
//         {
//             cycle: "Cycle",
//             //selector: row => row.cycle,
//             sortable: true
//         },
//         {
//             nextOncVisit: "Next Onc Visit",
//             //selector: row => row.nextOncVisit,
//             sortable: true
//         },
//         {
//             medStatus: "Medication Status",
//             //selector: row => row.medStatus,
//             sortable: true
//         },
//         {
//             missedDoses: "Missed Doses",
//             //selector: row => row.missedDoses,
//             sortable: true
//         },
//         {
//             barriers: "Barriers",
//             //selector: row => row.barriers,
//             sortable: true
//         },
//         {
//             symptoms: "Symptoms",
//             //selector: row => row.symptoms,
//             sortable: true
//         },
//         {
//             patientConcern: "Patient Concern Addressed",
//             //selector: row => row.patientConcern,
//             sortable: true
//         },
//         {
//             actions: "Actions",
//             //selector: row => row.actions,
//             sortable: false
//         }
//     ]

//     const data1 = [
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 2, "02/15/16", "Not Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 5, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Not Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 2, "02/15/16", "Not Delivered", "none", "None", "Nausea", "Complete Task", "icons"],
//         ["First,Last", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", "Nausea", "Complete Task", "icons"],

//     ];

//     const data = [
//         ["Bennie","481-63-1166","Nadolol",70,"1/11/2023","AS",null,"Mukah Airport",null,"MKM","AF"],
// ["Orelee","555-53-3106","Mint",46,"5/27/2023","NA",null,"Jardines Del Rey Airport",null,"CCC","AS"],
// ["Elinor","139-62-1492","ANTIBACTERIAL HAND",96,"2/21/2023","OC",null,"Springvale Airport",null,"KSV","AF"],
// ["Malissa","523-01-8888","oxygen",44,"6/8/2023","AF",null,"Boundji Airport",null,"BOE","OC"],
// ["Nikaniki","772-30-8570","Irbesartan and Hydrochlorothiazide",88,"9/16/2022","AF",null,"Mopti Airport",null,"MZI","AS"],
// ["Sydel","131-12-8722","Topcare Nicotine",21,"4/11/2023","AF",null,"Tzaneen Airport",null,"LTA","AS"],
// ["Philomena","839-38-9883","Ciprofloxacin",46,"8/31/2022","NA",null,"Rochester International Airport",null,"RST","NA"],
// ["Stacy","227-52-7105","Caffeine Citrate",32,"4/18/2023","NA",null,"Pittsburgh/Butler Regional Airport",null,"BTP","AS"],
// ["Gwenneth","785-50-4943","Good Neighbor Pharmacy headache relief",31,"6/27/2022","OC",null,"Honinabi Airport",null,"HNN","OC"],
// ["Ardine","274-50-8542","Esika Men Dandruff",62,"12/27/2022","EU",null,"Hjaltabakki Airport",null,"BLO","SA"],
// ["Sibel","817-12-9703","ziprasidone hydrochloride",72,"3/18/2023","AS",null,"Amakusa Airport",null,"AXJ","AS"],
// ["Rahel","803-65-3936","Haloperidol",67,"12/4/2022","SA",null,"Perai Tepuy Airport",null,"PPH","OC"],
// ["Augusta","151-47-3039","Face Protector Broad Spectrum SPF 40",30,"11/17/2022","EU",null,"Trondheim Airport Værnes",null,"TRD","NA"],
// ["Sydelle","211-21-6166","ethyl alcohol",61,"9/17/2022","OC",null,"Taskul Airport",null,"TSK","OC"],
//     ]

// //     const options = {
// //         download: false,
// //         print: false,
// //         viewColumns: false
// //     };
//     return (
//         <div>
//             <DataTable
//                 columns={columns}
//                 data={data}
//                 title="Patient Treatment Plan"
//                 selectableRows
//                 fixedHeader
//                 pagination
//             />
//         </div>
//     );
// };

// export default ReactDataTable;


export {}