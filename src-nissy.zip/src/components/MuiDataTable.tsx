import React, { useState } from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableSortLabel from "@material-ui/core/TableSortLabel";
import Paper from "@material-ui/core/Paper";
import { Button, Divider } from "@mui/material";
import sutterLogo from "../images/sutter-health-logo.png";
import { ButtonGroup } from "@material-ui/core";
import InputLabel from '@mui/material/InputLabel';
import { Box, TextField } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import { SelectChangeEvent } from '@mui/material/Select';
import { Select, MenuItem } from "@mui/material";
import "../../src/App.css";



function createData(name, mrn, treatmentPlan, cycle, nextVisit, medStatus, missedDoses, PatientConcernAddressed, barriers, symptoms, actions) {
    return { name, mrn, treatmentPlan, cycle, nextVisit, medStatus, missedDoses, PatientConcernAddressed, barriers, symptoms, actions };
}



const tableHeader = [
    "Name", "MRN", "Treatment Plan", "Cycle", "Next Onc Visit", "Medication Status",
    , "Missed Doses", "Barriers", "Symptoms", "Patient Concern Addressed", "Actions"
]


const rows = [
    // createData("Susan", "XXXXX", "Sunitinib", 0, "02/15/16", "Delivered", "none", "None", ""Nausea"", "Complete Task", "icons"),
    // createData("Allen", "XXXXX", "Sunitinib", 1, "02/15/17", "Delivered", "none", "None", "fever", "Complete Task", "icons"),
    // createData("John", "XXXXX", "Sunitinib", 2, "02/15/18", "Delivered", "none", "None", "diarrea", "Complete Task", "icons"),
    // createData("Rini", "XXXXX", "Sunitinib", 3, "02/15/19", "Not Delivered", "none", "None", ""Nausea"", "InComplete Task", "icons"),

    createData("Bennie", "481-63-1166", "Nadolol", 70, "1/11/2023", "Started", 2, "Mukah ", "Nausea", "Complete Task", "AF"),
    createData("Orelee", "555-53-3106", "Mint", 46, "5/27/2023", "NA", 5, "Jardines Del Rey ", "Nausea", "Completed", "AS"),
    createData("Elinor", "139-62-1492", "ANTIBACTERIAL HAND", 96, "2/21/2023", "started", 0, "Springvale ", "Nausea", "Completed", "AF"),
    createData("Malissa", "523-01-8888", "oxygen", 44, "6/8/2023", "NA", 0, "Boundji ", "Nausea", "Completed", "OC"),
    createData("Nikaniki", "772-30-8570", "Irbesartan and Hydrochlorothiazide", 88, "9/16/2022", "AF", 0, "Mopti ", "Nausea", "Completed", "AS"),
    createData("Sydel", "131-12-8722", "Topcare Nicotine", 21, "4/11/2023", "Started", 1, "Tzaneen ", "Nausea", "Completed", "AS"),
    createData("Philomena", "839-38-9883", "Ciprofloxacin", 46, "8/31/2022", "NA", 0, "Rochester International ", "Nausea", "Completed", "NA"),
    createData("Stacy", "227-52-7105", "Caffeine Citrate", 32, "4/18/2023", "NA", 5, "Pittsburgh/Butler Regional ", "Nausea", "Completed", "AS"),
    createData("Gwenneth", "785-50-4943", "Good Neighbor Pharmacy headache relief", 31, "6/27/2022", "OC", 2, "Honinabi ", "Nausea", "Completed", "OC"),
    createData("Ardine", "274-50-8542", "Esika Men Dandruff", 62, "12/27/2022", "Started", 1, "Hjaltabakki ", "Nausea", "BLO", "SA"),
    createData("Sibel", "817-12-9703", "ziprasidone hydrochloride", 72, "3/18/2023", "AS", 2, "Amakusa ", "Nausea", "AXJ", "AS"),
    createData("Rahel", "803-65-3936", "Haloperidol", 67, "12/4/2022", "SA", 0, "Perai Tepuy ", "Nausea", "PPH", "OC"),
    createData("Augusta", "151-47-3039", "Face Protector Broad Spectrum SPF 40", 30, "11/17/2022", "EU", "Nausea", "Trondheim  Værnes", "Nausea", "TRD", "NA"),
    createData("Sydelle", "211-21-6166", "ethyl alcohol", 61, "9/17/2022", "OC", 0, "Taskul ", "Nausea", "TSK", "OC"),

];


export default function MuiDataTable() {
    const [rowData, setRowData] = useState(rows);
    const [orderDirection, setOrderDirection] = useState("asc");
    const [dropDownValue, setDropDownValue] = useState("none");
    const [status, setStatus] = useState('Med Status');
    const [appDownloadList, setAppDownloadList] = useState<any>('App Downloaded');
    const [patientConcernsList, setPatientConcernsList] = useState<any>('Patient Concerns');
    const [clinicianList, setClinicianList] = useState<any>('Clinician');

    const medStatus = ['Med Status','Delivered', 'Not Delivered', 'Incorrect Medicine', 'Started'];
    const appDownload= ['App Downloaded',"Yes", "No"];
    const patientConcerns = ['Patient Concerns','Missed Doses', 'Barriers', 'Symptoms'];
    const clinician = ['Clinician','Alice', 'Allen'];

    const sortArray = (arr, orderBy) => {
        switch (orderBy) {
            case "asc":
            default:
                return arr.sort((a, b) =>
                    a.name > b.name ? 1 : b.name > a.name ? -1 : 0
                );
            case "desc":
                return arr.sort((a, b) =>
                    a.name < b.name ? 1 : b.name < a.name ? -1 : 0
                );
        }
    };

    const handleChange = (e) => {
        alert(e.target.value)
    }

    const handleSortRequest = () => {
        setRowData(sortArray(rows, orderDirection));
        setOrderDirection(orderDirection === "asc" ? "desc" : "asc");
    };

    const dropDownValues = [
        { title: "Med Status", values: ["started", "Yet to start"] },
        { title: "App Download", values: ["Yes", "No"] },
        { title: "Patient Reported", values: ["Missed Doses", "Barriers", "Symptoms"] },
        { title: "Clinician", values: ["Doctor", "Nurse", "Oncologist"] }
    ]

    return (
        <>
            <div className="Search-component" style={{ display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: "#F4F5F7" }}>
                <img src={sutterLogo} alt="Sutter-healthcare-logo" style={{ height: "100px", width: "300px" }} />
                <div style={{ display: "flex", alignItems: "center" }}>
                    <h4 style={{ textTransform: "uppercase", color: "#4A4D50", fontSize: "12px", fontWeight: "500", marginRight: "20px", margin: "0 20px 0 200px" }}>Oncology Patient Dashboard</h4>
                    <input placeholder="Search" /></div>
            </div>
            <div className="filter-component" style={{ height: "100px", display: "flex", alignItems: "center", justifyContent: "start" }}>
                <h4 style={{ textTransform: "uppercase", color: "#4A4D50", fontSize: "12px", fontWeight: "500", marginRight: "20px", margin: "0 20px 0 200px" }}>Select Filter</h4>

           

                <Select value={status} onChange={(e) => setStatus(e.target.value)}>
                    {
                        medStatus.map((med) => <MenuItem value={med}>{med}</MenuItem>)
                    }
                  
                </Select>
                <Select value={appDownloadList} onChange={(e) => setAppDownloadList(e.target.value)}>
                    {
                        appDownload.map((app) => <MenuItem value={app}>{app}</MenuItem>)
                    }
                  
                </Select>
                <Select value={patientConcernsList} onChange={(e) => setPatientConcernsList(e.target.value)}>
                    {
                        patientConcerns.map((med) => <MenuItem value={med}>{med}</MenuItem>)
                    }
                  
                </Select>
                <Select value={clinicianList} onChange={(e) => setClinicianList(e.target.value)}>
                    {
                        clinician.map((med) => <MenuItem value={med}>{med}</MenuItem>)
                    }
                  
                </Select>




            </div>
            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow className="row row-header">
                            {tableHeader.map((header) => {
                                return (
                                    <TableCell align="center">
                                        {header}
                                    </TableCell>
                                )
                            })}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {rowData.map((row) => {
                            return (
                                <TableRow className="row row-body">
                                    {Object.values(row).map(
                                        (row) => {
                                            return (
                                                <TableCell align="center">{row}</TableCell>
                                            )
                                        })}
                                </TableRow>
                            )
                        }
                        )}

                    </TableBody>
                </Table>
            </TableContainer>
        </>
    );
}


// export {}
