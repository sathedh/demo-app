import React, { useEffect, useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dropdown } from 'primereact/dropdown';
import { Button, InputLabel, MenuItem, Select, Typography } from "@mui/material";
import { InputText } from "primereact/inputtext";
import { FilterMatchMode } from "primereact/api";
import { Checkbox } from 'primereact/checkbox';
import axios from "axios";
import { ColumnGroup } from 'primereact/columngroup';
import { Row } from 'primereact/row';
import { Dialog } from 'primereact/dialog';
import ArrowDropDownOutlinedIcon from "@mui/icons-material/ArrowDropDownOutlined";
import {
  appDownloadStyles,
  clinicianStyles,
  columnStyles,
  filerContainer,
  globalHeaderStyles,
  headerStyles,
  medStatusStyles,
  patientReportedStyles,
  selectTextStyles,
  tableStyles,
  viewAllStyle,
  dropDownStyles,
  actionIconsStyles
} from "../constants/objects";
import "../css/styles.css";
import EmailIcon from "../images/message.png";
import CallIcon from "../images/call.png";
import GroupIcon from "../images/Group.png";

export default function DataTables() {
  const [patientData, setPatientData] = useState<any>();
  const [status, setStatus] = useState<any>(null);
  const [appDownloaded, setAppDownloaded] = useState<any>(null);
  const [patientConcernsList, setPatientConcernsList] = useState<any>(null);
  const [clinicianList, setClinicianList] = useState<any>(null);
  const [displayAccessCode, setDisplayAccessCode] = useState<any>(false);
  const [checked, setChecked] = useState<any>(false);


  const [filters, setFilters] = useState<any>({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    patient: { value: null, matchMode: FilterMatchMode.CONTAINS },
    mrn: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    t_plan: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    cycle: { value: null, matchMode: FilterMatchMode.CONTAINS },
    next_visit: { value: null, matchMode: FilterMatchMode.EQUALS },
    med_status: { value: null, matchMode: FilterMatchMode.EQUALS },
  });
  const [globalFilterValue, setGlobalFilterValue] = useState<string>("");

  const medStatus = ['Delivered', 'Not Delivered', 'Incorrect Medicine', 'Started'];
  const appDownload = ["Yes", "No"];
  const patientConcerns = ['Missed Doses', 'Barriers', 'Symptoms'];
  const clinician = ['Alice', 'Allen'];


  useEffect(() => {
    const data = axios.get("/db/patientData.json");
    data.then((response: any) => {
      setPatientData(response.data);
    });
  }, []);

  let i = 0;
  const rowClass = (data: any) => {
    i++;
    return {
      "bg-gray-200": i % 2 !== 0,
    };
  };
  const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    var _filters = { ...filters };
    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const setFilterSelected = (e: string) => {
    setStatus(e);
    const value = e;
    var _filters = { ...filters };
    _filters["med_status"].value = value;

    setFilters(_filters);

  };

  const clearAllFilters = () => {
    var _filters = { ...filters };
    _filters["med_status"].value = "";
    setFilters(_filters);
    setStatus("");
    setGlobalFilterValue("");
  }

  const clearPatientConcerns = () => {
    console.log()
    setChecked(!checked)
    var _patientData = patientData;
    _patientData[0]["missed_doses"] = null
    _patientData[0]["barriers"] = null
    _patientData[0]["symptoms"] = null
    setPatientData(_patientData);

  }

  const headerGroup = (
    <ColumnGroup>
      <Row>
        <Column header="Patient" rowSpan={2} headerStyle={headerStyles} />
        <Column header="MRN" rowSpan={2} headerStyle={headerStyles} />
        <Column header="Treatment Plan" rowSpan={2} headerStyle={headerStyles} />
        <Column header="Cycle" rowSpan={2} headerStyle={headerStyles} />
        <Column header="Next ONC Visit" rowSpan={2} headerStyle={headerStyles} />
        <Column header="Medication Status" rowSpan={2} headerStyle={headerStyles} />
        <Column header="Patient concerns" colSpan={3} headerStyle={headerStyles} />
        <Column header="Patient Concerns Addressed" rowSpan={2} headerStyle={headerStyles} />
        <Column header="Actions" rowSpan={2} headerStyle={headerStyles} />
      </Row>
      <Row>
        <Column header="Missed Doses" field="missed_doses" headerStyle={headerStyles} />
        <Column header="Barriers" field="barriers" headerStyle={headerStyles} />
        <Column header="Symptoms" field="Symptoms" headerStyle={headerStyles} />
      </Row>

    </ColumnGroup>
  );

  const patientConcernAddressed = (rowData) => {
    return (
      <>
        <Checkbox inputId="ingredient2" name={rowData.patient_concern} value={rowData.patient_concern} checked={checked} onChange={clearPatientConcerns} />
        <label htmlFor="ingredient2" className="ml-2"> {rowData.patient_concern} </label>
      </>
    )
  }

  const actionIcons = () => {
    return (

      <div className="actionIcons" style={actionIconsStyles}>

        <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg" onClick={() => setDisplayAccessCode(true)}>
          <g id="Group 632228">
            <circle id="Ellipse 2" cx="12.5" cy="12.5" r="11.5" stroke="#00A499" stroke-width="2" />
            <g id="Group 632227">
              <line id="Line 1" x1="4.16664" y1="13.5834" x2="13.317" y2="13.5834" stroke="#00A499" stroke-width="2" />
              <path id="Line 2" d="M13.8889 14.5834V4.86115" stroke="#00A499" stroke-width="2" />
            </g>
          </g>
        </svg>




        <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
          <g id="Group 632232">
            <path id="Rectangle 3465946" d="M20.1652 12.3987V1H1V23.7973H10.5826" stroke="#00A499" stroke-width="2" />
            <g id="Group 632231">
              <path id="Ellipse 6" d="M20.1615 17.9285C20.1615 20.5041 18.3122 22.4015 16.2537 22.4015C14.1952 22.4015 12.3459 20.5041 12.3459 17.9285C12.3459 15.3528 14.1952 13.4554 16.2537 13.4554C18.3122 13.4554 20.1615 15.3528 20.1615 17.9285Z" stroke="#00A499" stroke-width="2" />
              <rect id="Rectangle 3465947" width="7.50052" height="1.57703" transform="matrix(0.798357 0.602185 -0.564964 0.825116 20.0119 20.182)" fill="#00A499" />
            </g>
            <line id="Line 4" x1="2.9165" y1="5.52881" x2="17.9292" y2="5.52881" stroke="#00A499" />
            <line id="Line 5" x1="2.9165" y1="9.53479" x2="17.9292" y2="9.53479" stroke="#00A499" />
            <line id="Line 6" x1="2.9165" y1="13.5408" x2="10.902" y2="13.5408" stroke="#00A499" />
            <line id="Line 7" x1="2.9165" y1="17.5468" x2="9.94373" y2="17.5468" stroke="#00A499" />
          </g>
        </svg>

        <svg width="30" height="27" viewBox="0 0 30 27" fill="none" xmlns="http://www.w3.org/2000/svg">
          <g id="Group 632230">
            <rect id="Rectangle 3465945" x="1" y="1" width="28" height="25" rx="5" stroke="#00A499" stroke-width="2" />
            <g id="Group 632229">
              <ellipse id="Ellipse 3" cx="6.80645" cy="13" rx="1.80645" ry="4" fill="#00A499" />
              <ellipse id="Ellipse 4" cx="15.4194" cy="13" rx="1.80645" ry="4" fill="#00A499" />
              <ellipse id="Ellipse 5" cx="24.0323" cy="13" rx="1.80645" ry="4" fill="#00A499" />
            </g>
          </g>
        </svg>

      </div>


    )
  }
  const renderHeader = () => {
    return (
      <div style={globalHeaderStyles}>
        <Typography style={{ fontSize: "1rem" }}>
          ONCOLOGY PATIENT DASHBOARD
        </Typography>
        <div className="flex justify-content-center">
          <span
            className="p-input-icon-left"
            style={{
              display: "flex",
              flexDirection: "row",
            }}
          >
            <i className="pi pi-search" style={{ fontSize: "1.25rem" }} />
            <InputText
              style={{ width: "25rem", fontSize: "1rem" }}
              value={globalFilterValue}
              onChange={onGlobalFilterChange}
              placeholder="Search"
            />
          </span>
        </div>
      </div>
    );
  };
  const header = renderHeader();
  return (
    <div>
      <DataTable
        value={patientData}
        editMode="cell"
        tableStyle={tableStyles}
        paginator
        rows={10}
        rowsPerPageOptions={[5, 10, 25, 50]}
        rowHover
        rowClassName={rowClass}
        header={header}
        filters={filters}
        headerColumnGroup={headerGroup}
      >
        <Column
          style={columnStyles}
          field="patient"
          header="Patient"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="mrn"
          header="MRN"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="t_plan"
          header="Treatment Plan"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="cycle"
          header="Cycle"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="next_visit"
          header="Next Onc Visit"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="med_status"
          header="Medication Status"
          headerStyle={headerStyles}
        />

        <Column
          style={columnStyles}
          field="missed_doses"
          header="Missed Doses"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="barriers"
          header="Barriers"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="symptoms"
          header="Symptoms"
          headerStyle={headerStyles}
        />
        <Column
          style={columnStyles}
          field="patient_concern"
          header="Patient Concern Addressed"
          headerStyle={headerStyles}
          body={patientConcernAddressed}
        />
        <Column
          style={columnStyles}
          field='Actions'
          header="Actions"
          headerStyle={headerStyles}
          body={actionIcons}
        />
      </DataTable>
      <div style={filerContainer}>
        <div style={selectTextStyles}>Select filter:</div>
        <Button style={viewAllStyle} variant="contained" onClick={clearAllFilters}>
          View All
        </Button>

        <Dropdown value={status} onChange={(e) => setFilterSelected(e.value)} options={medStatus} style={dropDownStyles}
          placeholder="Med Status" className="w-full md:w-14rem" />
        <Dropdown value={appDownloaded} onChange={(e) => setFilterSelected(e.value)} options={appDownload} style={dropDownStyles}
          placeholder="App Download" className="w-full md:w-14rem" />
        <Dropdown value={patientConcernsList} onChange={(e) => setFilterSelected(e.value)} options={patientConcerns} style={dropDownStyles}
          placeholder="Patient Reported" className="w-full md:w-14rem" />
        <Dropdown value={clinicianList} onChange={(e) => setFilterSelected(e.value)} options={clinician} style={dropDownStyles}
          placeholder="Clinician" className="w-full md:w-14rem" />

      </div>


      <Dialog header="Access Code Options" visible={displayAccessCode} style={{ width: '20vw' }} onHide={() => setDisplayAccessCode(false)} >
        <p className="">

          <div className="Email access_icons">
            <img src={EmailIcon} />
            <p>Send Access Code to Email</p>
          </div>
          <div className="phone access_icons">
            <img src={CallIcon} />

            <p>Send Access Code to Phone</p>
          </div>
          <div className="proxycode access_icons">
            <img src={GroupIcon} />

            <p>Generate Proxy Access Code</p>
          </div>
        </p>
      </Dialog>
    </div>
  );
}
